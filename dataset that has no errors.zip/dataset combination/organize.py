import pandas as pd

df1 = pd.read_csv('trec5.csv',nrows=4000)
df2 = pd.read_csv('trec6.csv',nrows=2000)
df3 = pd.read_csv('trec7.csv')

df = pd.concat([df1,df2,df3],ignore_index=True)

df.dropna()
df.drop_duplicates(subset=['body'])

print(df.columns.values.tolist())
#print(df.loc[len(df)-1,'body'])

for col in df:
    df.contains("無標題文件")